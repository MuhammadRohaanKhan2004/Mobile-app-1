package com.example.oneactivitytosecondactivity;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class second extends AppCompatActivity {
    private Button save;
    private EditText taskName, taskDescription;

    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        taskName = findViewById(R.id.taskName);
        taskDescription = findViewById(R.id.taskDescription);
        save = findViewById(R.id.save);

        sharedPreferences = getSharedPreferences("TaskHistory", MODE_PRIVATE);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = taskName.getText().toString().trim();
                String description = taskDescription.getText().toString().trim();

                if (name.isEmpty()) {
                    taskName.setError("Task Name is required!");
                    taskName.requestFocus();
                } else if (description.isEmpty()) {
                    taskDescription.setError("Task Description is required!");
                    taskDescription.requestFocus();
                } else {
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("TASK_NAME", name);
                    editor.putString("TASK_DESCRIPTION", description);
                    editor.apply();

                    Intent intent = new Intent(second.this, save.class);
                    intent.putExtra("TASK_NAME", name);
                    intent.putExtra("TASK_DESCRIPTION", description);
                    startActivity(intent);
                }
            }
        });
    }
}
