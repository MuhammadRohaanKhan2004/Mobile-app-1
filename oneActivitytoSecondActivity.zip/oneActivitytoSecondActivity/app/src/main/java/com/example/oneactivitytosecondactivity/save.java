package com.example.oneactivitytosecondactivity;

import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class save extends AppCompatActivity {

    private Button historyButton;
    private TextView taskDetails;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_save);

        taskDetails = findViewById(R.id.taskDetails);
        historyButton = findViewById(R.id.historyButton);

        sharedPreferences = getSharedPreferences("TaskHistory", MODE_PRIVATE);

        historyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String savedName = sharedPreferences.getString("TASK_NAME", "No Task Found");
                String savedDescription = sharedPreferences.getString("TASK_DESCRIPTION", "No Description Found");

                taskDetails.setText("Saved Task Name: " + savedName + "\nSaved Task Description: " + savedDescription);
            }
        });
    }
}
